<?php

/**
 * Template part for displaying the narrative line on the homepage
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Evoli
 */

?>

<div id="narrative-line" aria-hidden="false"></div>